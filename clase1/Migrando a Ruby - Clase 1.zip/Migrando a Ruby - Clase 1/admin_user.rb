MY_CONSTANT = 'a'

def my_method
  my_var = 2
  other_var = 3
  if my_var == 2
  end

  unless my_var == 3
  end
end

def other_method arg1

end

def other_method(arg1, arg2)

end
p 'a'
